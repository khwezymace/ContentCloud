﻿using System;

namespace DemoSmartphoneAPI.Models
{
   public class Smartphone
   {
      public String ModelID { get; set; }
      public String ModelName { get; set; }
      public int SpecID { get; set; }
      public int BrandID { get; set; }
      public double Price { get; set; }
   }
}
