﻿using System;

namespace DemoSmartphoneAPI.Models
{
   public class Processor
   {
      public int ProcessorID { get; set; }

      public String ProcessorName { get; set; }
   }
}
