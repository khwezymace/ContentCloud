﻿using System;

namespace DemoSmartphoneAPI.Models
{
   public class Brand
   {
      public int BrandID { get; set; }

      public String BrandName { get; set; }

      public double BrandNetWorth { get; set; }
   }
}
